'''
Created on Nov 15, 2020

@author: sunil.thakur
'''
import json
from abc import abstractmethod
import subprocess

class Runtime(object):
    
    def __init__(self, config):        
        self.config = config
        
    @abstractmethod
    def start(self, pipeline):
        '''
        '''
    
    @abstractmethod    
    def status(self, jobid):
        '''
        '''
    
    def run_cmd(self, cmd):
        output = subprocess.check_output(cmd, shell = True)
        return output
        
class AWSRuntime(Runtime):
    
    def __init__(self, config):
        '''
        '''
        
    def start(self, pipeline_name):
        
        command = f'''aws emr create-cluster \
                        --release-label emr-5.32.0 \
                        --applications Name=Hadoop Name=Spark \
                        --steps Type=CUSTOM_JAR,ActionOnFailure=CONTINUE,Jar="command-runner.jar",Name="Spark application",Args=["spark-submit","--deploy-mode","cluster","--py-files","s3://edh2/data-pipeline/lib/data-pipeline.zip","--files","s3://edh2/data-pipeline/config/pipelines/{pipeline_name}.json","s3://edh2/data-pipeline/DataPipeline.py","{pipeline_name}"]  \
                        --instance-groups InstanceCount=1,InstanceGroupType=MASTER,InstanceType=m1.medium,Name="Master Instance Group" InstanceCount=1,InstanceGroupType=CORE,InstanceType=m1.large,Name="Core Instance Group"  \
                        --service-role EMR_DefaultRole --ec2-attributes InstanceProfile=EMR_EC2_DefaultRole \
                        --auto-terminate  \
                        --enable-debugging \
                        --name "Data Pipeline Cluster" \
                        --log-uri "s3n://aws-logs-859603162954-us-west-2/elasticmapreduce/" \
                        --region us-west-2
                    '''
  
        cmd_output = self.run_cmd(command)

        output = json.loads(cmd_output)
        print(output) 
        
        return output['ClusterId']


    def status(self, job_id):
        command = f''' aws emr \
                        describe-cluster --cluster-id {job_id}
                '''
        output = json.loads(self.run_cmd(command)) 
        return output['Cluster']['Status']['State']
    
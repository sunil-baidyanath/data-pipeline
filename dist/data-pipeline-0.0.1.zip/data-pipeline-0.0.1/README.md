# Data Pipeline

This is a sample project demonstrating usage of Python and AWS EMR to build a data pipeline.